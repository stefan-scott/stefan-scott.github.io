// CS30 - Final Programming Challenge
// Complete this comment header - - - (it's being graded!)
//
//
//
//
//

//variable declarations - included for convenience, but you don't have to use these.
//                        feel free to handle this in a different way if you prefer.


let foxLeft = [];   //array to hold all 8 images in each direction
let foxRight = [];   //array to hold all 8 images in each direction
let foxUp = [];   //array to hold all 8 images in each direction
let foxDown = [];   //array to hold all 8 images in each direction



async function setup() {
  createCanvas(windowWidth, windowHeight);
  loadAnimation();  //also defined at bottom
}

function draw() {
  background(220);
  image(foxLeft[0],width/2,height/2);  
}



async function loadAnimation(){
  // loads all the fox images into 4 arrays
  // each array holds images for a different direction
  // left, right, up, and down
  
  for(let i = 1; i <= 8; i++){    //0-7 LEFT
    foxLeft.push(await loadImage("/assets/left" + i + ".png"))
  }

  for(let i = 1; i <= 8; i++){  //0-7 RIGHT
    foxRight.push(await loadImage("/assets/right" + i + ".png"))
  }

  for(let i = 1; i <= 8; i++){  //0-7 UP
    foxUp.push(await loadImage("/assets/up" + i + ".png"))
  }

  for(let i = 1; i <= 8; i++){  //0-8 DOWN
    foxDown.push(await loadImage("/assets/down" + i + ".png"))
  }
}