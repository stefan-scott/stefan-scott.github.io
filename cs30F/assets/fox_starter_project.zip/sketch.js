// CS30 - Final Programming Challenge
// Complete this comment header - - - (it's being graded!)
//
//
//
//
//

//variable declarations - included for convenience, but you don't have to use these.
//                        feel free to handle this in a different way if you prefer.


let foxLeft = [];   //array to hold all 8 images for LEFT
let foxRight = [];   //array to hold all 8 images for RIGHT
let foxUp = [];   //array to hold all 8 images for UP
let foxDown = [];   //array to hold all 8 images for DOWN



async function setup() {
  createCanvas(windowWidth, windowHeight);
  await loadAnimation();  //also defined at bottom
}

function draw() {
  background(220);
  image(foxLeft[0],width/2,height/2);  //example - you'll need to change this
}




// ---------------- Shouldn't need to modify below this line ----------------

async function loadAnimation(){
  // loads all the fox images into 4 arrays
  // each array holds images for a different direction
  // left, right, up, and down
  
  for(let i = 1; i <= 8; i++){    //0-7 LEFT
    foxLeft.push(await loadImage("./assets/left" + i + ".png"));
  }

  for(let i = 1; i <= 8; i++){  //0-7 RIGHT
    foxRight.push(await loadImage("./assets/right" + i + ".png"));
  }

  for(let i = 1; i <= 8; i++){  //0-7 UP
    foxUp.push(await loadImage("./assets/up" + i + ".png"));
  }

  for(let i = 1; i <= 8; i++){  //0-7 DOWN
    foxDown.push(await loadImage("./assets/down" + i + ".png"));
  }
}